//
//  ZCApplication.h
//  34-App启动过程
//
//  Created by Fearless on 2020/4/5.
//  Copyright © 2020 XFB. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZCApplication : UIApplication

@end

NS_ASSUME_NONNULL_END
