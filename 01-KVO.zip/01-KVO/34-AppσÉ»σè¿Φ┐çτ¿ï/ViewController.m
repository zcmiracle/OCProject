//
//  ViewController.m
//  34-App启动过程
//
//  Created by Fearless on 2020/4/4.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (IBAction)changeAnchorPoint:(UIButton *)sender {
}


@end
