//
//  App启动过程笔记.h
//  01-KVO
//
//  Created by Fearless on 2020/4/5.
//  Copyright © 2020 XFB. All rights reserved.
//

#ifndef App_______h
#define App_______h

UIApplicationMain
1、创建了一个application对象
2、设置application的代理
3、建立一个事件循环
4、info.plist 文件 NSMainNibFile属性读取

UIWindow
1、app的第一个视图控件
2、通常app中只有一个，特殊的UIView
3、window层级
4、window的hidden默认是隐藏的，添加和移除



#endif /* App_______h */
