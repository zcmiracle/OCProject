//
//  Person.m
//  11-load
//
//  Created by XFB on 2020/3/23.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Person.h"

@implementation Person

+ (void)load {
    NSLog(@"%s", __func__);
}

@end
