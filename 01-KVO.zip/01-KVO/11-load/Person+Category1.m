//
//  Person+Category1.m
//  11-load
//
//  Created by XFB on 2020/3/23.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Person+Category1.h"

@implementation Person (Category1)

+ (void)load {
    NSLog(@"%s", __func__);
}

@end
