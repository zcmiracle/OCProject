//
//  Student+Category2.h
//  11-load
//
//  Created by XFB on 2020/3/23.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Student.h"

NS_ASSUME_NONNULL_BEGIN

@interface Student (Category2)

@end

NS_ASSUME_NONNULL_END
