//
//  Person+Category1.h
//  11-load
//
//  Created by XFB on 2020/3/23.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Person.h"

NS_ASSUME_NONNULL_BEGIN

@interface Person (Category1)

@end

NS_ASSUME_NONNULL_END
