//
//  ThreadViewController.h
//  26-线程保活
//
//  Created by XFB on 2020/3/30.
//  Copyright © 2020 XFB. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ThreadViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
