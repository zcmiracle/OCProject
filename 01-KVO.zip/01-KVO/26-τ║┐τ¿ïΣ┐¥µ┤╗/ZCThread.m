//
//  ZCThread.m
//  26-线程保活
//
//  Created by XFB on 2020/3/30.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "ZCThread.h"

@implementation ZCThread

- (void)dealloc {
    NSLog(@"%s", __func__);
}

@end
