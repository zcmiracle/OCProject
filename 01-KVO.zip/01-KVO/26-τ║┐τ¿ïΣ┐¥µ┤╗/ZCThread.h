//
//  ZCThread.h
//  26-线程保活
//
//  Created by XFB on 2020/3/30.
//  Copyright © 2020 XFB. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZCThread : NSThread

@end

NS_ASSUME_NONNULL_END
