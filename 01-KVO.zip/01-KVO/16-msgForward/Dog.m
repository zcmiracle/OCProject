//
//  Dog.m
//  16-msgForward
//
//  Created by XFB on 2020/3/24.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Dog.h"

@implementation Dog

- (void)run {
    NSLog(@"%s", __func__);
}

@end
