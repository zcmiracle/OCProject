//
//  YellowView.h
//  28-事件传递及响应
//
//  Created by XFB on 2020/3/30.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "BaseView.h"

NS_ASSUME_NONNULL_BEGIN

@interface YellowView : BaseView

@end

NS_ASSUME_NONNULL_END
