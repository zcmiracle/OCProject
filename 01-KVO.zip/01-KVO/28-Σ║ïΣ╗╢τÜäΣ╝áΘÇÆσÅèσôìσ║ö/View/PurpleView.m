//
//  PurpleView.m
//  28-事件传递及响应
//
//  Created by XFB on 2020/3/30.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "PurpleView.h"

@implementation PurpleView

@end
