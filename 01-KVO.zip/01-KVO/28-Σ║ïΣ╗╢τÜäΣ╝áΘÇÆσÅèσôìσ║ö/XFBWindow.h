//
//  XFBWindow.h
//  28-事件传递及响应
//
//  Created by XFB on 2020/3/30.
//  Copyright © 2020 XFB. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XFBWindow : UIWindow

@end

NS_ASSUME_NONNULL_END
