//
//  UserModel.m
//  15-runtime添加ivar
//
//  Created by XFB on 2020/3/24.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "UserModel.h"

@implementation UserModel

@end
