//
//  AutomaticCell.h
//  43-RuntimeSafeCategory
//
//  Created by XFB on 2020/5/12.
//  Copyright © 2020 XFB. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AutomaticCell : UITableViewCell

@property (nonatomic, copy) NSString *typeString;

@end

NS_ASSUME_NONNULL_END
