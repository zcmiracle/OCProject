
//
//  ZCTest.m
//  30-copyIvarList+copyPropertyList
//
//  Created by XFB on 2020/3/30.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "ZCTest.h"


@interface ZCTest ()

@property (nonatomic, copy) NSString *age123;

@end

@implementation ZCTest

{
    NSString *height;
    NSString *_width;
}

@end
