//
//  ZCTest+Category.h
//  30-copyIvarList+copyPropertyList
//
//  Created by Fearless on 2020/4/4.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "ZCTest.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZCTest (Category)

@property (nonatomic, copy) NSString *categoryAge;

@end

NS_ASSUME_NONNULL_END
