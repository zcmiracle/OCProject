//
//  Student+Category1.h
//  11-load
//
//  Created by XFB on 2020/3/23.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Student.h"

NS_ASSUME_NONNULL_BEGIN

@interface Student (Category1)

@end

NS_ASSUME_NONNULL_END
