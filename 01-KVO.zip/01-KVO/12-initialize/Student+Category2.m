//
//  Student+Category2.m
//  11-load
//
//  Created by XFB on 2020/3/23.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Student+Category2.h"

@implementation Student (Category2)

//+ (void)initialize {
//    NSLog(@"%s", __func__);
//}

@end
