//
//  Teacher.m
//  12-initialize
//
//  Created by XFB on 2020/3/23.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Teacher.h"

@implementation Teacher

//+ (void)initialize {
//    NSLog(@"%s", __func__);
//}

@end
