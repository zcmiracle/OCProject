//
//  Person+Category2.m
//  13-Category
//
//  Created by XFB on 2020/3/23.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Person+Category2.h"

@implementation Person (Category2)

- (void)test {
    NSLog(@"%s", __func__);
}

@end
