//
//  Test.m
//  22-isMemberOf+isKindOf
//
//  Created by XFB on 2020/3/26.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Test.h"

@implementation Test

@end
