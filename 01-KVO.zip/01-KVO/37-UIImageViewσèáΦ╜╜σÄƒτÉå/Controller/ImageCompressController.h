//
//  ImageCompressController.h
//  37-UIImageView加载原理
//
//  Created by XFB on 2020/4/7.
//  Copyright © 2020 XFB. All rights reserved.
//  压缩相册图片

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ImageCompressController : UIViewController

@end

NS_ASSUME_NONNULL_END
