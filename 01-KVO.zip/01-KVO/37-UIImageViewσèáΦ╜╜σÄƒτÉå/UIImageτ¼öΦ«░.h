//
//  UIImage笔记.h
//  01-KVO
//
//  Created by XFB on 2020/4/7.
//  Copyright © 2020 XFB. All rights reserved.
//

#ifndef UIImage___h
#define UIImage___h

1、图片压缩
    1.1 直接格式转换png(RGBA) jpg(RGB)
    1.2 Context 重新绘制

2、图片处理
    2.1 基于图片像素修改
    2.2 图片裁剪
    2.3 渲染render
    2.4 截屏


#endif /* UIImage___h */
