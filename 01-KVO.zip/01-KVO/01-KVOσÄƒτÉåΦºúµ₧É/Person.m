//
//  Person.m
//  01-KVO
//
//  Created by XFB on 2020/3/20.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Person.h"

@implementation Person

@end
