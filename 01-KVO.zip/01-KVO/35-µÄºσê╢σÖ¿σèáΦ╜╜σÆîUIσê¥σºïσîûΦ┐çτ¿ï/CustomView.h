//
//  CustomView.h
//  35-控制器加载和UI初始化过程
//
//  Created by Fearless on 2020/4/5.
//  Copyright © 2020 XFB. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// 可视化
IB_DESIGNABLE

@interface CustomView : UIView

@end

NS_ASSUME_NONNULL_END
