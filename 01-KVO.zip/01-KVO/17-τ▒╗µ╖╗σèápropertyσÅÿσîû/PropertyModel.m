//
//  PropertyModel.m
//  17-类添加property变化
//
//  Created by Fearless on 2020/3/24.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "PropertyModel.h"

@implementation PropertyModel

@end
