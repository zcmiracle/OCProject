//
//  BezierPathViewController.m
//  39-动画Animation
//
//  Created by XFB on 2020/4/8.
//  Copyright © 2020 XFB. All rights reserved.
//  贝塞尔曲线

#import "BezierPathViewController.h"

@interface BezierPathViewController ()
{
    CAShapeLayer *_shapeLayer;
}
@end

@implementation BezierPathViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
}


@end
