//
//  AppDelegate.h
//  25-子线程开启RunLoop
//
//  Created by XFB on 2020/3/27.
//  Copyright © 2020 XFB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

