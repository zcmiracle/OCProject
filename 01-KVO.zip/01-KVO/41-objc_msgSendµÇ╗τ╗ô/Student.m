//
//  Student.m
//  41-objc_msgSend总结
//
//  Created by XFB on 2020/4/10.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Student.h"

@implementation Student

- (void)studying {
    NSLog(@"Student studying");
}

@end
