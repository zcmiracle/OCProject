//
//  Person.m
//  41-objc_msgSend总结
//
//  Created by XFB on 2020/4/10.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Person.h"

@implementation Person

- (void)playing {
    NSLog(@"Person playing");
}

+ (void)sleeping {
    NSLog(@"Person sleeping");
}

@end
