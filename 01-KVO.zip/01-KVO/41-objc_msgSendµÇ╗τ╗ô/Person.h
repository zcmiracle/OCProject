//
//  Person.h
//  41-objc_msgSend总结
//
//  Created by XFB on 2020/4/10.
//  Copyright © 2020 XFB. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject

- (void)playing;
+ (void)sleeping;

@end

NS_ASSUME_NONNULL_END
