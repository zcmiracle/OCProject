//
//  Student.h
//  41-objc_msgSend总结
//
//  Created by XFB on 2020/4/10.
//  Copyright © 2020 XFB. All rights reserved.
//

#import "Person.h"

NS_ASSUME_NONNULL_BEGIN

@interface Student : Person

- (void)studying;

@end

NS_ASSUME_NONNULL_END
